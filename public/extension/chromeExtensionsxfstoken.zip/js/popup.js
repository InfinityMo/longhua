$('#day').click(function () {
  debugger
})